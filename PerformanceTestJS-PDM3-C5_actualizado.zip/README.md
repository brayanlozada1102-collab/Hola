# Workspace Reservation SPA

Includes:
- Authentication
- Session persistence with localStorage
- Role handling (admin/user)
- Route protection
- Reservation listing
- JSON Server backend

Test users:
admin@test.com / A123456
user@test.com / A123456
user2@test.com / A123456
