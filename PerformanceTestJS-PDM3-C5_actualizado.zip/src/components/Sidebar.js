
import { removeSession } from "@/utils";
import { navigateTo } from "@/router/router";

export default function Sidebar() {
 setTimeout(()=>{
   document.querySelector("#logoutBtn")?.addEventListener("click",()=>{
      removeSession();
      navigateTo("/");
   });
 });
 return `<aside class="w-64 bg-slate-900 text-white h-screen p-5">
 <h2 class="text-2xl font-bold mb-8">Reservations SPA</h2>
 <nav class="flex flex-col gap-4">
 <a href="/home">Home</a>
 <button id="logoutBtn">Cerrar sesión</button>
 </nav></aside>`;
}
