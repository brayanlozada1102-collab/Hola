
import loginView from "@/views/loginView";
import homeView from "@/views/homeView";
import { isAuthenticated } from "@/utils";

const routes = { "/": loginView, "/home": homeView };

export const navigateTo=(path)=>{ history.pushState({}, "", path); router(); };

export const router=()=>{
 const app=document.querySelector("#app");
 const path=window.location.pathname;
 if(path!=="/" && !isAuthenticated()){ history.replaceState({}, "", "/"); }
 const view=routes[window.location.pathname] || loginView;
 app.innerHTML=view();
};
window.addEventListener("popstate", router);
