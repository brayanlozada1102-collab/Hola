# SpaceBook — Workspace Reservation SPA

## Description

SpaceBook is a Single Page Application (SPA) built with Vanilla JavaScript and Vite that allows company employees to reserve shared workspaces (meeting rooms, private offices, coworking areas, auditoriums). Administrators can manage all reservations and spaces, while regular users can create and manage their own reservations.

## Technologies Used

| Technology | Purpose |
|---|---|
| Vite | Build tool & dev server |
| Vanilla JavaScript (ES Modules) | Core application logic |
| TailwindCSS v4 | Styling |
| json-server | REST API mock |
| concurrently | Run Vite + json-server simultaneously |

## Installation

```bash
# Clone or unzip the project
cd PerformanceTestFull

# Install dependencies
npm install
```

## Running the Project

```bash
# Starts both Vite (port 5173) and json-server (port 3001) concurrently
npm run dev
```

Then open [http://localhost:5173](http://localhost:5173) in your browser.

## Running json-server Only

```bash
npx json-server --watch db.json --port 3001
```

## Test Users

| Name | Email | Password | Role |
|---|---|---|---|
| Administrador | admin@test.com | Admin123* | admin |
| Usuario | user@test.com | User123* | user |
| Usuario 2 | user2@test.com | User123* | user |

## Project Structure

```
src/
├── api/
│   └── http.js                  # Fetch wrapper (GET, POST, PUT, PATCH, DELETE)
├── assets/                      # Static assets
├── components/
│   ├── ReservationCard.js       # Reservation card with role-aware action buttons
│   └── Sidebar.js               # Navigation sidebar with role-based links
├── controllers/
│   ├── home.controller.js       # Dashboard stats and recent reservations
│   ├── login.controller.js      # Login form handling and validation
│   ├── reservations.controller.js # Full CRUD for reservations + filters
│   └── spaces.controller.js     # Full CRUD for spaces (admin only)
├── router/
│   └── router.js                # Hash-free SPA router with auth & role guards
├── services/
│   ├── reservation.service.js   # Reservation API calls
│   └── space.service.js         # Space API calls
├── views/
│   ├── homeView.js              # Dashboard view
│   ├── loginView.js             # Login form view
│   ├── notFound.js              # 404 view
│   ├── reservationsView.js      # Reservations list + modal form
│   └── spacesView.js            # Spaces list + modal form (admin)
├── main.js                      # Entry point
├── style.css                    # Tailwind import
└── utils.js                     # Session helpers, toast notifications, status formatters
db.json                          # json-server database
```

## Role Permissions

### Admin
- ✅ View all reservations from all users
- ✅ Create reservations
- ✅ Edit any reservation (any status)
- ✅ Delete any reservation
- ✅ Approve or reject reservations
- ✅ Create, edit, disable and delete workspaces
- ✅ Access admin-only routes (`/spaces`)

### User
- ✅ Create reservations
- ✅ View only their own reservations
- ✅ Edit their own **pending** reservations
- ✅ Cancel their own reservations (pending or approved)
- ❌ Cannot approve/reject reservations
- ❌ Cannot access `/spaces`
- ❌ Cannot see other users' reservations

## Technical Decisions

### SPA Routing
Uses the History API (`pushState`) without hash for clean URLs. A global `router()` function handles view rendering. Route guards check authentication and role before every render, redirecting unauthenticated users to `/` and unauthorized users to an "Access Denied" screen.

### Session Persistence
User data (`id`, `name`, `role`, `email`) is stored in `localStorage` so the session survives page refreshes. On logout, `removeSession()` clears the storage and redirects to `/`.

### Modular Architecture
Each concern is separated: views (HTML templates), controllers (event binding + business logic), services (API calls), and utils (shared helpers). Controllers are called via `setTimeout` inside views to ensure DOM is available before binding events.

### Business Rules Enforced
- Duplicate reservation prevention: checks same space + date + overlapping time range (excluding cancelled/rejected).
- Users can only edit **pending** reservations; approved ones can only be cancelled.
- Admin bypasses user-level restrictions.

### Toast Notifications
Implemented as a lightweight utility (`showToast`) that injects notifications at the top-right corner without any external library.

## Bonus Features Implemented
- 📊 Dashboard with live stats (total, pending, approved, rejected)
- 🔍 Reservation search by space name or reason
- 📅 Filter by date and status
- 🏢 Workspace management module (admin only, linked to reservations)
- 🔔 Toast notifications for all actions
- 👁️ Password visibility toggle on login
