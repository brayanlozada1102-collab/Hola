import { statusLabel, statusColor, isAdmin } from "@/utils";

export default function ReservationCard(reservation, users = []) {
  const { id, workspace, date, startHour, endHour, reason, status, userId } = reservation;

  const ownerName = users.find((u) => u.id === userId)?.name || `Usuario #${userId}`;

  const canApproveReject = isAdmin() && (status === "pending");
  const canEdit = isAdmin() || status === "pending";
  const canCancel = status === "pending" || status === "approved";
  const canDelete = isAdmin();

  return `
    <article class="bg-white rounded-xl border border-slate-200 p-5 hover:shadow-md transition" data-id="${id}">
      <div class="flex items-start justify-between gap-2 mb-3">
        <div>
          <h3 class="font-semibold text-slate-800">${workspace}</h3>
          ${isAdmin() ? `<p class="text-xs text-slate-400 mt-0.5">Por: ${ownerName}</p>` : ""}
        </div>
        <span class="text-xs font-medium px-2.5 py-1 rounded-full flex-shrink-0 ${statusColor(status)}">
          ${statusLabel(status)}
        </span>
      </div>

      <div class="space-y-1.5 text-sm text-slate-600 mb-4">
        <div class="flex items-center gap-2">
          <svg class="w-4 h-4 text-slate-400 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/>
          </svg>
          ${date}
        </div>
        <div class="flex items-center gap-2">
          <svg class="w-4 h-4 text-slate-400 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/>
          </svg>
          ${startHour} – ${endHour}
        </div>
        <div class="flex items-center gap-2">
          <svg class="w-4 h-4 text-slate-400 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
          </svg>
          ${reason}
        </div>
      </div>

      <div class="flex flex-wrap gap-2 border-t pt-3">
        ${canApproveReject ? `
          <button data-action="approve" data-id="${id}" class="btn-action flex-1 bg-green-600 hover:bg-green-700 text-white text-xs px-3 py-1.5 rounded-lg transition">
            ✓ Aprobar
          </button>
          <button data-action="reject" data-id="${id}" class="btn-action flex-1 bg-red-500 hover:bg-red-600 text-white text-xs px-3 py-1.5 rounded-lg transition">
            ✗ Rechazar
          </button>
        ` : ""}
        ${canEdit ? `
          <button data-action="edit" data-id="${id}" class="btn-action flex-1 bg-blue-50 hover:bg-blue-100 text-blue-700 text-xs px-3 py-1.5 rounded-lg transition border border-blue-200">
            Editar
          </button>
        ` : ""}
        ${canCancel && !isAdmin() ? `
          <button data-action="cancel" data-id="${id}" class="btn-action flex-1 bg-slate-50 hover:bg-slate-100 text-slate-600 text-xs px-3 py-1.5 rounded-lg transition border border-slate-200">
            Cancelar
          </button>
        ` : ""}
        ${canDelete ? `
          <button data-action="delete" data-id="${id}" class="btn-action bg-red-50 hover:bg-red-100 text-red-600 text-xs px-3 py-1.5 rounded-lg transition border border-red-200">
            Eliminar
          </button>
        ` : ""}
      </div>
    </article>
  `;
}
