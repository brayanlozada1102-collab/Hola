import { removeSession, getSession, isAdmin } from "@/utils";
import { navigateTo } from "@/router/router";

export default function Sidebar(activePath = "/home") {
  const user = getSession();

  const navLinks = [
    { path: "/home", label: "Inicio", icon: `<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"/>` },
    { path: "/reservations", label: "Reservas", icon: `<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/>` },
  ];

  if (isAdmin()) {
    navLinks.push({ path: "/spaces", label: "Espacios", icon: `<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-2 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"/>` });
  }

  setTimeout(() => {
    document.querySelector("#logoutBtn")?.addEventListener("click", () => {
      removeSession();
      navigateTo("/");
    });

    document.querySelectorAll("[data-link]").forEach((link) => {
      link.addEventListener("click", (e) => {
        e.preventDefault();
        navigateTo(link.dataset.path);
      });
    });
  });

  return `
    <aside class="w-64 bg-slate-900 text-white h-screen p-5 flex flex-col flex-shrink-0">

      <div class="mb-8">
        <div class="flex items-center gap-2 mb-1">
          <div class="w-8 h-8 bg-blue-500 rounded-lg flex items-center justify-center">
            <svg class="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-2 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"/>
            </svg>
          </div>
          <span class="text-lg font-bold">SpaceBook</span>
        </div>
        <p class="text-slate-400 text-xs">Gestión de espacios</p>
      </div>

      <nav class="flex flex-col gap-1 flex-1">
        ${navLinks.map(({ path, label, icon }) => `
          <a
            href="${path}"
            data-link
            data-path="${path}"
            class="flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition
              ${activePath === path
                ? "bg-blue-600 text-white"
                : "text-slate-300 hover:bg-slate-800 hover:text-white"
              }"
          >
            <svg class="w-5 h-5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">${icon}</svg>
            ${label}
          </a>
        `).join("")}
      </nav>

      <div class="border-t border-slate-700 pt-4">
        <div class="flex items-center gap-3 px-3 mb-3">
          <div class="w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold
            ${user?.role === "admin" ? "bg-purple-500" : "bg-blue-500"}">
            ${user?.name?.charAt(0) || "U"}
          </div>
          <div class="min-w-0">
            <p class="text-sm font-medium text-white truncate">${user?.name || "Usuario"}</p>
            <p class="text-xs text-slate-400 capitalize">${user?.role === "admin" ? "Administrador" : "Usuario"}</p>
          </div>
        </div>

        <button
          id="logoutBtn"
          class="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-red-400 hover:bg-red-500/10 hover:text-red-300 transition cursor-pointer"
        >
          <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
              d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"/>
          </svg>
          Cerrar sesión
        </button>
      </div>
    </aside>
  `;
}
