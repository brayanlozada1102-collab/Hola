import { getReservations } from "@/services/reservation.service";
import { getSession, isAdmin, statusLabel, statusColor } from "@/utils";

export const homeController = async () => {
  const user = getSession();

  try {
    const allReservations = await getReservations();
    const myReservations = isAdmin()
      ? allReservations
      : allReservations.filter((r) => r.userId === user.id);

    // Stats
    const pending = myReservations.filter((r) => r.status === "pending").length;
    const approved = myReservations.filter((r) => r.status === "approved").length;
    const rejected = myReservations.filter((r) => r.status === "rejected").length;
    const total = myReservations.length;

    const statsContainer = document.querySelector("#statsContainer");
    if (statsContainer) {
      statsContainer.innerHTML = `
        ${statCard("Total", total, "bg-blue-50", "text-blue-700", "📋")}
        ${statCard("Pendientes", pending, "bg-yellow-50", "text-yellow-700", "⏳")}
        ${statCard("Aprobadas", approved, "bg-green-50", "text-green-700", "✅")}
        ${statCard("Rechazadas", rejected, "bg-red-50", "text-red-700", "❌")}
      `;
    }

    // Recent reservations (last 3)
    const recent = [...myReservations].reverse().slice(0, 3);
    const recentContainer = document.querySelector("#recentReservations");
    if (recentContainer) {
      recentContainer.innerHTML = recent.length
        ? `<div class="divide-y divide-slate-100">
            ${recent.map((r) => `
              <div class="py-3 flex items-center justify-between gap-4">
                <div>
                  <p class="text-sm font-medium text-slate-800">${r.workspace}</p>
                  <p class="text-xs text-slate-400">${r.date} · ${r.startHour}–${r.endHour}</p>
                </div>
                <span class="text-xs font-medium px-2.5 py-1 rounded-full flex-shrink-0 ${statusColor(r.status)}">
                  ${statusLabel(r.status)}
                </span>
              </div>
            `).join("")}
          </div>
          <div class="mt-4">
            <button onclick="window.navigateTo('/reservations')"
              class="text-sm text-blue-600 hover:text-blue-700 font-medium">
              Ver todas →
            </button>
          </div>`
        : `<p class="text-slate-400 text-sm py-4 text-center">No tienes reservas aún.</p>`;
    }
  } catch (err) {
    console.error(err);
  }
};

const statCard = (label, value, bg, textColor, icon) => `
  <div class="bg-white rounded-xl p-4 border border-slate-200">
    <div class="flex items-center justify-between mb-2">
      <p class="text-xs text-slate-500 font-medium">${label}</p>
      <span class="text-lg">${icon}</span>
    </div>
    <p class="text-2xl font-bold ${textColor}">${value}</p>
  </div>
`;
