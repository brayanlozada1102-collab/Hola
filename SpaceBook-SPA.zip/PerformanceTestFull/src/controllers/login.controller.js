import { saveSession, showToast } from "@/utils";
import { navigateTo } from "@/router/router";
import { http } from "@/api/http";

export const loginController = () => {
  const form = document.querySelector("#loginForm");
  const loginBtn = document.querySelector("#loginBtn");
  const togglePassword = document.querySelector("#togglePassword");
  const passwordInput = document.querySelector("#passwordInput");

  // Toggle password visibility
  togglePassword?.addEventListener("click", () => {
    const type = passwordInput.getAttribute("type") === "password" ? "text" : "password";
    passwordInput.setAttribute("type", type);
  });

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    clearErrors();

    const email = form.email.value.trim();
    const password = form.password.value.trim();

    // Validation
    let hasError = false;
    if (!email) {
      showFieldError("emailError", "El correo es requerido");
      hasError = true;
    } else if (!/\S+@\S+\.\S+/.test(email)) {
      showFieldError("emailError", "Ingresa un correo válido");
      hasError = true;
    }
    if (!password) {
      showFieldError("passwordError", "La contraseña es requerida");
      hasError = true;
    }
    if (hasError) return;

    // Loading state
    loginBtn.disabled = true;
    loginBtn.innerHTML = `
      <svg class="animate-spin w-4 h-4" fill="none" viewBox="0 0 24 24">
        <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"/>
        <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z"/>
      </svg>
      Verificando...
    `;

    try {
      const users = await http.get(`/users?email=${encodeURIComponent(email)}&password=${encodeURIComponent(password)}`);

      if (!users.length) {
        showLoginError("Correo o contraseña incorrectos");
        return;
      }

      const user = users[0];
      saveSession({ id: user.id, name: user.name, role: user.role, email: user.email });
      showToast(`¡Bienvenido, ${user.name}!`, "success");
      navigateTo("/home");
    } catch (error) {
      console.error(error);
      showLoginError("Error al conectar con el servidor. Verifica que json-server esté corriendo.");
    } finally {
      loginBtn.disabled = false;
      loginBtn.innerHTML = "Iniciar sesión";
    }
  });
};

const clearErrors = () => {
  ["emailError", "passwordError"].forEach((id) => {
    const el = document.querySelector(`#${id}`);
    if (el) { el.textContent = ""; el.classList.add("hidden"); }
  });
  const loginError = document.querySelector("#loginError");
  if (loginError) { loginError.textContent = ""; loginError.classList.add("hidden"); }
};

const showFieldError = (id, msg) => {
  const el = document.querySelector(`#${id}`);
  if (el) { el.textContent = msg; el.classList.remove("hidden"); }
};

const showLoginError = (msg) => {
  const el = document.querySelector("#loginError");
  if (el) { el.textContent = msg; el.classList.remove("hidden"); }
};
