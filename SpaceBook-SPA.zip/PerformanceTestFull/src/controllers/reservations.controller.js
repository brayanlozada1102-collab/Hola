import ReservationCard from "@/components/ReservationCard";
import {
  getReservations,
  createReservation,
  updateReservation,
  deleteReservation,
} from "@/services/reservation.service";
import { getSpaces } from "@/services/space.service";
import { http } from "@/api/http";
import { getSession, isAdmin, showToast } from "@/utils";

let allReservations = [];
let allSpaces = [];
let allUsers = [];

export const reservationsController = async () => {
  const user = getSession();

  try {
    [allReservations, allSpaces, allUsers] = await Promise.all([
      getReservations(),
      getSpaces(),
      http.get("/users"),
    ]);
  } catch (err) {
    console.error(err);
    showToast("Error al cargar datos", "error");
    return;
  }

  renderReservations();
  populateSpacesSelect();
  bindFilters();
  bindNewReservationBtn();
  bindModal();
};

// ─── Render ────────────────────────────────────────────────────────────────

const renderReservations = (filtered = null) => {
  const user = getSession();
  const container = document.querySelector("#reservationsContainer");
  if (!container) return;

  let list = filtered ?? allReservations;

  if (!isAdmin()) {
    list = list.filter((r) => r.userId === user.id);
  }

  container.innerHTML = list.length
    ? list.map((r) => ReservationCard(r, allUsers)).join("")
    : `<div class="col-span-full text-center py-12">
        <div class="text-4xl mb-3">📭</div>
        <p class="text-slate-500">No se encontraron reservas</p>
      </div>`;

  bindCardActions();
};

// ─── Filters ───────────────────────────────────────────────────────────────

const bindFilters = () => {
  const search = document.querySelector("#searchInput");
  const dateFilter = document.querySelector("#dateFilter");
  const statusFilter = document.querySelector("#statusFilter");
  const clearBtn = document.querySelector("#clearFilters");

  const applyFilters = () => {
    let list = [...allReservations];
    const q = search?.value.toLowerCase().trim();
    const date = dateFilter?.value;
    const status = statusFilter?.value;

    if (q) list = list.filter((r) => r.workspace.toLowerCase().includes(q) || r.reason.toLowerCase().includes(q));
    if (date) list = list.filter((r) => r.date === date);
    if (status) list = list.filter((r) => r.status === status);

    renderReservations(list);
  };

  search?.addEventListener("input", applyFilters);
  dateFilter?.addEventListener("change", applyFilters);
  statusFilter?.addEventListener("change", applyFilters);
  clearBtn?.addEventListener("click", () => {
    if (search) search.value = "";
    if (dateFilter) dateFilter.value = "";
    if (statusFilter) statusFilter.value = "";
    renderReservations();
  });
};

// ─── Spaces Select ─────────────────────────────────────────────────────────

const populateSpacesSelect = () => {
  const select = document.querySelector("#spaceSelect");
  if (!select) return;
  const available = allSpaces.filter((s) => s.status === "available");
  select.innerHTML = `<option value="">Selecciona un espacio...</option>` +
    available.map((s) => `<option value="${s.id}" data-name="${s.name}">${s.name} (${s.type} · Cap. ${s.capacity})</option>`).join("");
};

// ─── New Reservation Button ────────────────────────────────────────────────

const bindNewReservationBtn = () => {
  document.querySelector("#newReservationBtn")?.addEventListener("click", () => openModal());
};

// ─── Modal ─────────────────────────────────────────────────────────────────

const openModal = (reservation = null) => {
  const modal = document.querySelector("#reservationModal");
  const title = document.querySelector("#modalTitle");
  const form = document.querySelector("#reservationForm");

  clearFormErrors();
  form.reset();
  document.querySelector("#reservationId").value = "";

  populateSpacesSelect();

  if (reservation) {
    title.textContent = "Editar Reserva";
    document.querySelector("#reservationId").value = reservation.id;
    document.querySelector("#reservationDate").value = reservation.date;
    document.querySelector("#startHour").value = reservation.startHour;
    document.querySelector("#endHour").value = reservation.endHour;
    document.querySelector("#reason").value = reservation.reason;

    // Set space
    const spaceSelect = document.querySelector("#spaceSelect");
    const opt = [...spaceSelect.options].find((o) => o.dataset.name === reservation.workspace);
    if (opt) spaceSelect.value = opt.value;

    if (isAdmin()) {
      document.querySelector("#statusSelect").value = reservation.status;
    }
  } else {
    title.textContent = "Nueva Reserva";
    // Default date = today
    document.querySelector("#reservationDate").value = new Date().toISOString().split("T")[0];
  }

  modal.classList.remove("hidden");
};

const closeModal = () => {
  document.querySelector("#reservationModal")?.classList.add("hidden");
};

const bindModal = () => {
  document.querySelector("#closeModal")?.addEventListener("click", closeModal);
  document.querySelector("#cancelFormBtn")?.addEventListener("click", closeModal);
  document.querySelector("#reservationModal")?.addEventListener("click", (e) => {
    if (e.target === e.currentTarget) closeModal();
  });

  document.querySelector("#reservationForm")?.addEventListener("submit", handleFormSubmit);
};

// ─── Form Submit ───────────────────────────────────────────────────────────

const handleFormSubmit = async (e) => {
  e.preventDefault();
  clearFormErrors();

  const id = document.querySelector("#reservationId").value;
  const spaceEl = document.querySelector("#spaceSelect");
  const spaceId = parseInt(spaceEl.value);
  const spaceName = spaceEl.options[spaceEl.selectedIndex]?.dataset.name;
  const date = document.querySelector("#reservationDate").value;
  const startHour = document.querySelector("#startHour").value;
  const endHour = document.querySelector("#endHour").value;
  const reason = document.querySelector("#reason").value.trim();
  const status = isAdmin() ? document.querySelector("#statusSelect")?.value : "pending";

  // Validation
  let hasError = false;
  if (!spaceId) { showFormFieldError("spaceError", "Selecciona un espacio"); hasError = true; }
  if (!date) { showFormFieldError("dateError", "La fecha es requerida"); hasError = true; }
  if (!startHour) { showFormFieldError("startError", "La hora de inicio es requerida"); hasError = true; }
  if (!endHour) { showFormFieldError("endError", "La hora de fin es requerida"); hasError = true; }
  if (startHour && endHour && startHour >= endHour) {
    showFormFieldError("endError", "La hora de fin debe ser mayor a la hora de inicio"); hasError = true;
  }
  if (!reason) { showFormFieldError("reasonError", "El motivo es requerido"); hasError = true; }
  if (hasError) return;

  // Duplicate check
  const duplicate = allReservations.find((r) =>
    r.spaceId === spaceId &&
    r.date === date &&
    r.status !== "cancelled" && r.status !== "rejected" &&
    r.id !== parseInt(id) &&
    !(endHour <= r.startHour || startHour >= r.endHour)
  );
  if (duplicate) {
    showFormError("Ya existe una reserva para ese espacio en ese horario.");
    return;
  }

  const user = getSession();
  const payload = {
    userId: user.id,
    spaceId,
    workspace: spaceName,
    date,
    startHour,
    endHour,
    reason,
    status: status || "pending",
  };

  const btn = document.querySelector("#submitReservationBtn");
  btn.disabled = true;
  btn.textContent = "Guardando...";

  try {
    if (id) {
      const existing = allReservations.find((r) => r.id === parseInt(id));
      // Business rules: user can only edit pending
      if (!isAdmin() && existing?.status !== "pending") {
        showFormError("Solo puedes editar reservas pendientes.");
        return;
      }
      await updateReservation(id, payload);
      showToast("Reserva actualizada correctamente", "success");
    } else {
      await createReservation(payload);
      showToast("Reserva creada correctamente", "success");
    }

    closeModal();
    // Refresh
    allReservations = await getReservations();
    renderReservations();
  } catch (err) {
    console.error(err);
    showFormError("Error al guardar la reserva.");
  } finally {
    btn.disabled = false;
    btn.textContent = "Guardar";
  }
};

// ─── Card Actions ──────────────────────────────────────────────────────────

const bindCardActions = () => {
  document.querySelectorAll(".btn-action").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const action = btn.dataset.action;
      const id = parseInt(btn.dataset.id);
      const reservation = allReservations.find((r) => r.id === id);
      if (!reservation) return;

      if (action === "edit") {
        openModal(reservation);
      } else if (action === "approve") {
        await changeStatus(id, "approved");
      } else if (action === "reject") {
        await changeStatus(id, "rejected");
      } else if (action === "cancel") {
        if (confirm("¿Cancelar esta reserva?")) await changeStatus(id, "cancelled");
      } else if (action === "delete") {
        if (confirm("¿Eliminar esta reserva permanentemente?")) {
          await deleteReservation(id);
          showToast("Reserva eliminada", "info");
          allReservations = await getReservations();
          renderReservations();
        }
      }
    });
  });
};

const changeStatus = async (id, status) => {
  try {
    await updateReservation(id, { status });
    showToast(`Reserva ${status === "approved" ? "aprobada" : status === "rejected" ? "rechazada" : "cancelada"}`, "success");
    allReservations = await getReservations();
    renderReservations();
  } catch (err) {
    showToast("Error al actualizar la reserva", "error");
  }
};

// ─── Error Helpers ─────────────────────────────────────────────────────────

const clearFormErrors = () => {
  ["spaceError", "dateError", "startError", "endError", "reasonError"].forEach((id) => {
    const el = document.querySelector(`#${id}`);
    if (el) { el.textContent = ""; el.classList.add("hidden"); }
  });
  const fe = document.querySelector("#formError");
  if (fe) { fe.textContent = ""; fe.classList.add("hidden"); }
};

const showFormFieldError = (id, msg) => {
  const el = document.querySelector(`#${id}`);
  if (el) { el.textContent = msg; el.classList.remove("hidden"); }
};

const showFormError = (msg) => {
  const el = document.querySelector("#formError");
  if (el) { el.textContent = msg; el.classList.remove("hidden"); }
};
