import { getSpaces, createSpace, updateSpace, deleteSpace } from "@/services/space.service";
import { showToast } from "@/utils";

let allSpaces = [];

export const spacesController = async () => {
  try {
    allSpaces = await getSpaces();
  } catch (err) {
    showToast("Error al cargar espacios", "error");
    return;
  }

  renderSpaces();
  bindNewSpaceBtn();
  bindModal();
};

// ─── Render ────────────────────────────────────────────────────────────────

const spaceTypeIcon = (type) => {
  const icons = {
    "Sala de reuniones": "🏢",
    "Oficina privada": "🚪",
    "Espacio de coworking": "💻",
    "Auditorio": "🎭",
  };
  return icons[type] || "📍";
};

const renderSpaces = () => {
  const container = document.querySelector("#spacesContainer");
  if (!container) return;

  container.innerHTML = allSpaces.length
    ? allSpaces.map((s) => `
      <div class="bg-white rounded-xl border border-slate-200 p-5 hover:shadow-md transition" data-space-id="${s.id}">
        <div class="flex items-start justify-between mb-3">
          <div class="flex items-center gap-3">
            <span class="text-2xl">${spaceTypeIcon(s.type)}</span>
            <div>
              <h3 class="font-semibold text-slate-800">${s.name}</h3>
              <p class="text-xs text-slate-400 mt-0.5">${s.type}</p>
            </div>
          </div>
          <span class="text-xs font-medium px-2.5 py-1 rounded-full flex-shrink-0
            ${s.status === "available" ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"}">
            ${s.status === "available" ? "Disponible" : "No disponible"}
          </span>
        </div>

        <div class="space-y-1.5 text-sm text-slate-600 mb-4">
          <div class="flex items-center gap-2">
            <svg class="w-4 h-4 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/>
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/>
            </svg>
            ${s.location}
          </div>
          <div class="flex items-center gap-2">
            <svg class="w-4 h-4 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z"/>
            </svg>
            Capacidad: ${s.capacity} personas
          </div>
        </div>

        <div class="flex gap-2 border-t pt-3">
          <button data-space-action="edit" data-space-id="${s.id}"
            class="flex-1 bg-purple-50 hover:bg-purple-100 text-purple-700 text-xs px-3 py-1.5 rounded-lg transition border border-purple-200">
            Editar
          </button>
          <button data-space-action="toggle" data-space-id="${s.id}"
            class="flex-1 bg-slate-50 hover:bg-slate-100 text-slate-600 text-xs px-3 py-1.5 rounded-lg transition border border-slate-200">
            ${s.status === "available" ? "Deshabilitar" : "Habilitar"}
          </button>
          <button data-space-action="delete" data-space-id="${s.id}"
            class="bg-red-50 hover:bg-red-100 text-red-600 text-xs px-3 py-1.5 rounded-lg transition border border-red-200">
            Eliminar
          </button>
        </div>
      </div>
    `).join("")
    : `<div class="col-span-full text-center py-12">
        <div class="text-4xl mb-3">🏗️</div>
        <p class="text-slate-500">No hay espacios registrados</p>
      </div>`;

  bindSpaceCardActions();
};

// ─── New Space Button ──────────────────────────────────────────────────────

const bindNewSpaceBtn = () => {
  document.querySelector("#newSpaceBtn")?.addEventListener("click", () => openSpaceModal());
};

// ─── Modal ─────────────────────────────────────────────────────────────────

const openSpaceModal = (space = null) => {
  const modal = document.querySelector("#spaceModal");
  const title = document.querySelector("#spaceModalTitle");
  clearSpaceErrors();
  document.querySelector("#spaceForm").reset();
  document.querySelector("#spaceId").value = "";

  if (space) {
    title.textContent = "Editar Espacio";
    document.querySelector("#spaceId").value = space.id;
    document.querySelector("#spaceName").value = space.name;
    document.querySelector("#spaceType").value = space.type;
    document.querySelector("#spaceCapacity").value = space.capacity;
    document.querySelector("#spaceLocation").value = space.location;
    document.querySelector("#spaceStatus").value = space.status;
  } else {
    title.textContent = "Nuevo Espacio";
  }

  modal.classList.remove("hidden");
};

const closeSpaceModal = () => {
  document.querySelector("#spaceModal")?.classList.add("hidden");
};

const bindModal = () => {
  document.querySelector("#closeSpaceModal")?.addEventListener("click", closeSpaceModal);
  document.querySelector("#cancelSpaceBtn")?.addEventListener("click", closeSpaceModal);
  document.querySelector("#spaceModal")?.addEventListener("click", (e) => {
    if (e.target === e.currentTarget) closeSpaceModal();
  });
  document.querySelector("#spaceForm")?.addEventListener("submit", handleSpaceSubmit);
};

// ─── Form Submit ───────────────────────────────────────────────────────────

const handleSpaceSubmit = async (e) => {
  e.preventDefault();
  clearSpaceErrors();

  const id = document.querySelector("#spaceId").value;
  const name = document.querySelector("#spaceName").value.trim();
  const type = document.querySelector("#spaceType").value;
  const capacity = parseInt(document.querySelector("#spaceCapacity").value);
  const location = document.querySelector("#spaceLocation").value.trim();
  const status = document.querySelector("#spaceStatus").value;

  let hasError = false;
  if (!name) { showSpaceFieldError("spaceNameError", "El nombre es requerido"); hasError = true; }
  if (!type) { showSpaceFieldError("spaceTypeError", "El tipo es requerido"); hasError = true; }
  if (!capacity || capacity < 1) { showSpaceFieldError("spaceCapacityError", "La capacidad debe ser mayor a 0"); hasError = true; }
  if (!location) { showSpaceFieldError("spaceLocationError", "La ubicación es requerida"); hasError = true; }
  if (hasError) return;

  const payload = { name, type, capacity, location, status };
  const btn = document.querySelector("#submitSpaceBtn");
  btn.disabled = true;
  btn.textContent = "Guardando...";

  try {
    if (id) {
      await updateSpace(id, payload);
      showToast("Espacio actualizado", "success");
    } else {
      await createSpace(payload);
      showToast("Espacio creado", "success");
    }
    closeSpaceModal();
    allSpaces = await getSpaces();
    renderSpaces();
  } catch (err) {
    document.querySelector("#spaceFormError").textContent = "Error al guardar el espacio.";
    document.querySelector("#spaceFormError").classList.remove("hidden");
  } finally {
    btn.disabled = false;
    btn.textContent = "Guardar";
  }
};

// ─── Card Actions ──────────────────────────────────────────────────────────

const bindSpaceCardActions = () => {
  document.querySelectorAll("[data-space-action]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const action = btn.dataset.spaceAction;
      const id = parseInt(btn.dataset.spaceId);
      const space = allSpaces.find((s) => s.id === id);
      if (!space) return;

      if (action === "edit") {
        openSpaceModal(space);
      } else if (action === "toggle") {
        const newStatus = space.status === "available" ? "unavailable" : "available";
        await updateSpace(id, { status: newStatus });
        showToast(`Espacio ${newStatus === "available" ? "habilitado" : "deshabilitado"}`, "info");
        allSpaces = await getSpaces();
        renderSpaces();
      } else if (action === "delete") {
        if (confirm(`¿Eliminar "${space.name}"? Esta acción no se puede deshacer.`)) {
          await deleteSpace(id);
          showToast("Espacio eliminado", "info");
          allSpaces = await getSpaces();
          renderSpaces();
        }
      }
    });
  });
};

// ─── Error Helpers ─────────────────────────────────────────────────────────

const clearSpaceErrors = () => {
  ["spaceNameError", "spaceTypeError", "spaceCapacityError", "spaceLocationError"].forEach((id) => {
    const el = document.querySelector(`#${id}`);
    if (el) { el.textContent = ""; el.classList.add("hidden"); }
  });
  const fe = document.querySelector("#spaceFormError");
  if (fe) { fe.textContent = ""; fe.classList.add("hidden"); }
};

const showSpaceFieldError = (id, msg) => {
  const el = document.querySelector(`#${id}`);
  if (el) { el.textContent = msg; el.classList.remove("hidden"); }
};
