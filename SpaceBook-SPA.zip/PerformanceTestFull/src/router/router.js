import loginView from "@/views/loginView";
import homeView from "@/views/homeView";
import reservationsView from "@/views/reservationsView";
import spacesView from "@/views/spacesView";
import notFound from "@/views/notFound";
import { isAuthenticated, isAdmin, showToast } from "@/utils";

const routes = {
  "/": loginView,
  "/home": homeView,
  "/reservations": reservationsView,
  "/spaces": spacesView,
};

// Routes that require admin role
const adminRoutes = ["/spaces"];

// Routes accessible only when NOT authenticated
const publicRoutes = ["/"];

export const navigateTo = (path) => {
  history.pushState({}, "", path);
  router();
};

export const router = () => {
  const app = document.querySelector("#app");
  const path = window.location.pathname;

  // If not authenticated and trying to access protected route
  if (!publicRoutes.includes(path) && !isAuthenticated()) {
    history.replaceState({}, "", "/");
    app.innerHTML = loginView();
    return;
  }

  // If authenticated and on login page, redirect to home
  if (path === "/" && isAuthenticated()) {
    history.replaceState({}, "", "/home");
    app.innerHTML = homeView();
    return;
  }

  // If user tries to access admin-only route
  if (adminRoutes.includes(path) && !isAdmin()) {
    app.innerHTML = `
      <div class="min-h-screen flex items-center justify-center bg-slate-100">
        <div class="bg-white p-10 rounded-2xl shadow text-center max-w-md">
          <div class="text-6xl mb-4">🚫</div>
          <h1 class="text-2xl font-bold text-red-600 mb-2">Acceso Denegado</h1>
          <p class="text-slate-600 mb-6">No tienes permisos para acceder a este módulo.</p>
          <button onclick="window.navigateTo('/home')" class="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700">
            Volver al inicio
          </button>
        </div>
      </div>
    `;
    return;
  }

  const view = routes[path] || notFound;
  app.innerHTML = view();
};

// Expose navigateTo globally for inline onclick handlers
window.navigateTo = navigateTo;

window.addEventListener("popstate", router);
