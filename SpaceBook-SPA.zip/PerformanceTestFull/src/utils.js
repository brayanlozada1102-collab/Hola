// ─── Session Management ────────────────────────────────────────────────────

export const saveSession = (user) => {
  localStorage.setItem("user", JSON.stringify(user));
};

export const getSession = () => {
  return JSON.parse(localStorage.getItem("user"));
};

export const removeSession = () => {
  localStorage.removeItem("user");
};

export const isAuthenticated = () => !!getSession();

export const isAdmin = () => getSession()?.role === "admin";

// ─── Toast Notifications ───────────────────────────────────────────────────

export const showToast = (message, type = "success") => {
  const existing = document.querySelector(".toast-container");
  if (!existing) {
    const container = document.createElement("div");
    container.className = "toast-container fixed top-5 right-5 z-50 flex flex-col gap-2";
    document.body.appendChild(container);
  }

  const toast = document.createElement("div");
  const colors = {
    success: "bg-green-600",
    error: "bg-red-600",
    warning: "bg-yellow-500",
    info: "bg-blue-600",
  };
  toast.className = `${colors[type] || "bg-slate-800"} text-white px-5 py-3 rounded-lg shadow-lg text-sm transition-all duration-300 opacity-0 translate-x-4`;
  toast.textContent = message;

  document.querySelector(".toast-container").appendChild(toast);

  requestAnimationFrame(() => {
    toast.classList.remove("opacity-0", "translate-x-4");
  });

  setTimeout(() => {
    toast.classList.add("opacity-0", "translate-x-4");
    setTimeout(() => toast.remove(), 300);
  }, 3000);
};

// ─── Status Helpers ────────────────────────────────────────────────────────

export const statusLabel = (status) => {
  const map = {
    pending: "Pendiente",
    approved: "Aprobada",
    rejected: "Rechazada",
    cancelled: "Cancelada",
  };
  return map[status] || status;
};

export const statusColor = (status) => {
  const map = {
    pending: "bg-yellow-100 text-yellow-800",
    approved: "bg-green-100 text-green-800",
    rejected: "bg-red-100 text-red-800",
    cancelled: "bg-slate-100 text-slate-600",
  };
  return map[status] || "bg-slate-100 text-slate-600";
};
