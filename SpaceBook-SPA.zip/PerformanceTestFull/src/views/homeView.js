import Sidebar from "@/components/Sidebar";
import { getSession, isAdmin } from "@/utils";
import { homeController } from "@/controllers/home.controller";

export default function homeView() {
  const user = getSession();

  setTimeout(() => homeController());

  return `
    <div class="flex h-screen overflow-hidden">
      ${Sidebar("/home")}

      <main class="flex-1 overflow-y-auto bg-slate-100">
        <div class="p-6 max-w-6xl mx-auto">

          <div class="mb-6">
            <h1 class="text-2xl font-bold text-slate-800">
              Bienvenido, ${user?.name} 👋
            </h1>
            <p class="text-slate-500 text-sm mt-1">
              ${isAdmin() ? "Panel de administración" : "Panel de usuario"} · 
              <span class="${isAdmin() ? "text-purple-600" : "text-blue-600"} font-medium capitalize">
                ${isAdmin() ? "Administrador" : "Usuario"}
              </span>
            </p>
          </div>

          <!-- Stats -->
          <div id="statsContainer" class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
            <div class="bg-white rounded-xl p-4 border border-slate-200 animate-pulse">
              <div class="h-4 bg-slate-200 rounded w-1/2 mb-2"></div>
              <div class="h-8 bg-slate-200 rounded w-1/3"></div>
            </div>
            <div class="bg-white rounded-xl p-4 border border-slate-200 animate-pulse">
              <div class="h-4 bg-slate-200 rounded w-1/2 mb-2"></div>
              <div class="h-8 bg-slate-200 rounded w-1/3"></div>
            </div>
            <div class="bg-white rounded-xl p-4 border border-slate-200 animate-pulse">
              <div class="h-4 bg-slate-200 rounded w-1/2 mb-2"></div>
              <div class="h-8 bg-slate-200 rounded w-1/3"></div>
            </div>
            <div class="bg-white rounded-xl p-4 border border-slate-200 animate-pulse">
              <div class="h-4 bg-slate-200 rounded w-1/2 mb-2"></div>
              <div class="h-8 bg-slate-200 rounded w-1/3"></div>
            </div>
          </div>

          <!-- Quick Actions -->
          <div class="bg-white rounded-xl border border-slate-200 p-5 mb-6">
            <h2 class="font-semibold text-slate-800 mb-4">Acciones rápidas</h2>
            <div class="flex flex-wrap gap-3">
              <button onclick="window.navigateTo('/reservations')"
                class="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2.5 rounded-lg text-sm font-medium transition">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/>
                </svg>
                Nueva reserva
              </button>
              <button onclick="window.navigateTo('/reservations')"
                class="flex items-center gap-2 bg-slate-100 hover:bg-slate-200 text-slate-700 px-4 py-2.5 rounded-lg text-sm font-medium transition">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/>
                </svg>
                Ver mis reservas
              </button>
              ${isAdmin() ? `
                <button onclick="window.navigateTo('/spaces')"
                  class="flex items-center gap-2 bg-purple-50 hover:bg-purple-100 text-purple-700 px-4 py-2.5 rounded-lg text-sm font-medium transition border border-purple-200">
                  <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-2 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"/>
                  </svg>
                  Gestionar espacios
                </button>
              ` : ""}
            </div>
          </div>

          <!-- Recent Reservations -->
          <div class="bg-white rounded-xl border border-slate-200 p-5">
            <h2 class="font-semibold text-slate-800 mb-4">
              ${isAdmin() ? "Reservas recientes" : "Mis reservas recientes"}
            </h2>
            <div id="recentReservations">
              <p class="text-slate-400 text-sm py-4 text-center">Cargando...</p>
            </div>
          </div>

        </div>
      </main>
    </div>
  `;
}
