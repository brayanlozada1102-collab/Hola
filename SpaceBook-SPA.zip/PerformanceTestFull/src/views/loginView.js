import { loginController } from "@/controllers/login.controller";

export default function loginView() {
  setTimeout(() => {
    loginController();
  });

  return `
    <div class="min-h-screen flex justify-center items-center bg-gradient-to-br from-slate-900 to-blue-900">
      <div class="bg-white p-8 rounded-2xl shadow-xl w-full max-w-sm">

        <div class="text-center mb-8">
          <div class="inline-flex items-center justify-center w-14 h-14 bg-blue-600 rounded-full mb-3">
            <svg class="w-7 h-7 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-2 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"/>
            </svg>
          </div>
          <h1 class="text-2xl font-bold text-slate-800">SpaceBook</h1>
          <p class="text-slate-500 text-sm mt-1">Gestión de Espacios de Trabajo</p>
        </div>

        <form id="loginForm" novalidate>

          <div class="mb-4">
            <label class="block text-sm font-medium text-slate-700 mb-1">Correo electrónico</label>
            <input
              type="email"
              name="email"
              placeholder="correo@empresa.com"
              class="border border-slate-300 w-full p-2.5 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 transition"
            >
            <p id="emailError" class="text-red-500 text-xs mt-1 hidden"></p>
          </div>

          <div class="mb-5">
            <label class="block text-sm font-medium text-slate-700 mb-1">Contraseña</label>
            <div class="relative">
              <input
                type="password"
                name="password"
                id="passwordInput"
                placeholder="••••••••"
                class="border border-slate-300 w-full p-2.5 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 transition pr-10"
              >
              <button type="button" id="togglePassword"
                class="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/>
                </svg>
              </button>
            </div>
            <p id="passwordError" class="text-red-500 text-xs mt-1 hidden"></p>
          </div>

          <div id="loginError" class="hidden bg-red-50 border border-red-200 text-red-700 text-sm rounded-lg p-3 mb-4"></div>

          <button
            id="loginBtn"
            type="submit"
            class="bg-blue-600 hover:bg-blue-700 text-white w-full py-2.5 rounded-lg font-medium transition flex items-center justify-center gap-2"
          >
            Iniciar sesión
          </button>

        </form>

        <div class="mt-6 border-t pt-4">
          <p class="text-xs text-slate-400 text-center mb-2">Usuarios de prueba</p>
          <div class="text-xs text-slate-500 space-y-1">
            <p>👑 admin@test.com / Admin123*</p>
            <p>👤 user@test.com / User123*</p>
          </div>
        </div>

      </div>
    </div>
  `;
}
