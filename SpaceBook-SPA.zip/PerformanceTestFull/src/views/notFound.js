export default function notFound() {
  return `
    <div class="min-h-screen flex items-center justify-center bg-slate-100">
      <div class="bg-white p-10 rounded-2xl shadow text-center max-w-md">
        <div class="text-7xl mb-4">🔍</div>
        <h1 class="text-3xl font-bold text-slate-800 mb-2">404</h1>
        <p class="text-slate-500 mb-6">La página que buscas no existe.</p>
        <button onclick="window.navigateTo('/home')"
          class="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2.5 rounded-lg transition font-medium">
          Volver al inicio
        </button>
      </div>
    </div>
  `;
}
