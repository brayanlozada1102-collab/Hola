import Sidebar from "@/components/Sidebar";
import { getSession, isAdmin } from "@/utils";
import { reservationsController } from "@/controllers/reservations.controller";

export default function reservationsView() {
  setTimeout(() => reservationsController());

  return `
    <div class="flex h-screen overflow-hidden">
      ${Sidebar("/reservations")}

      <main class="flex-1 overflow-y-auto bg-slate-100">
        <div class="p-6 max-w-6xl mx-auto">

          <div class="flex items-center justify-between mb-6">
            <div>
              <h1 class="text-2xl font-bold text-slate-800">Reservas</h1>
              <p class="text-slate-500 text-sm mt-1" id="reservationsSubtitle">
                ${isAdmin() ? "Todas las reservas del sistema" : "Mis reservas"}
              </p>
            </div>
            <button id="newReservationBtn"
              class="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2.5 rounded-lg text-sm font-medium transition">
              <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/>
              </svg>
              Nueva reserva
            </button>
          </div>

          <!-- Filters -->
          <div class="bg-white rounded-xl border border-slate-200 p-4 mb-5 flex flex-wrap gap-3">
            <input
              type="text"
              id="searchInput"
              placeholder="Buscar por espacio o motivo..."
              class="border border-slate-200 rounded-lg px-3 py-2 text-sm flex-1 min-w-40 focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
            <input
              type="date"
              id="dateFilter"
              class="border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
            <select
              id="statusFilter"
              class="border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="">Todos los estados</option>
              <option value="pending">Pendiente</option>
              <option value="approved">Aprobada</option>
              <option value="rejected">Rechazada</option>
              <option value="cancelled">Cancelada</option>
            </select>
            <button id="clearFilters"
              class="text-sm text-slate-500 hover:text-slate-700 px-3 py-2 rounded-lg hover:bg-slate-50 transition">
              Limpiar
            </button>
          </div>

          <!-- Reservations Grid -->
          <div id="reservationsContainer" class="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
            <div class="col-span-full text-center py-12">
              <p class="text-slate-400">Cargando reservas...</p>
            </div>
          </div>

        </div>
      </main>
    </div>

    <!-- Modal -->
    <div id="reservationModal" class="hidden fixed inset-0 bg-black/50 z-40 flex items-center justify-center p-4">
      <div class="bg-white rounded-2xl shadow-xl w-full max-w-lg max-h-[90vh] overflow-y-auto">
        <div class="p-6">
          <div class="flex items-center justify-between mb-5">
            <h2 class="text-xl font-bold text-slate-800" id="modalTitle">Nueva Reserva</h2>
            <button id="closeModal" class="text-slate-400 hover:text-slate-600 transition">
              <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
              </svg>
            </button>
          </div>

          <form id="reservationForm" novalidate class="space-y-4">
            <input type="hidden" id="reservationId">

            <div>
              <label class="block text-sm font-medium text-slate-700 mb-1">Espacio *</label>
              <select id="spaceSelect"
                class="border border-slate-300 w-full p-2.5 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm">
                <option value="">Selecciona un espacio...</option>
              </select>
              <p class="text-red-500 text-xs mt-1 hidden" id="spaceError"></p>
            </div>

            <div>
              <label class="block text-sm font-medium text-slate-700 mb-1">Fecha *</label>
              <input type="date" id="reservationDate"
                class="border border-slate-300 w-full p-2.5 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm">
              <p class="text-red-500 text-xs mt-1 hidden" id="dateError"></p>
            </div>

            <div class="grid grid-cols-2 gap-3">
              <div>
                <label class="block text-sm font-medium text-slate-700 mb-1">Hora inicio *</label>
                <input type="time" id="startHour"
                  class="border border-slate-300 w-full p-2.5 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm">
                <p class="text-red-500 text-xs mt-1 hidden" id="startError"></p>
              </div>
              <div>
                <label class="block text-sm font-medium text-slate-700 mb-1">Hora fin *</label>
                <input type="time" id="endHour"
                  class="border border-slate-300 w-full p-2.5 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm">
                <p class="text-red-500 text-xs mt-1 hidden" id="endError"></p>
              </div>
            </div>

            <div>
              <label class="block text-sm font-medium text-slate-700 mb-1">Motivo *</label>
              <textarea id="reason" rows="3" placeholder="Describe el motivo de la reserva..."
                class="border border-slate-300 w-full p-2.5 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm resize-none"></textarea>
              <p class="text-red-500 text-xs mt-1 hidden" id="reasonError"></p>
            </div>

            ${isAdmin() ? `
              <div>
                <label class="block text-sm font-medium text-slate-700 mb-1">Estado</label>
                <select id="statusSelect"
                  class="border border-slate-300 w-full p-2.5 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm">
                  <option value="pending">Pendiente</option>
                  <option value="approved">Aprobada</option>
                  <option value="rejected">Rechazada</option>
                  <option value="cancelled">Cancelada</option>
                </select>
              </div>
            ` : ""}

            <div id="formError" class="hidden bg-red-50 border border-red-200 text-red-700 text-sm rounded-lg p-3"></div>

            <div class="flex gap-3 pt-2">
              <button type="button" id="cancelFormBtn"
                class="flex-1 border border-slate-300 text-slate-700 py-2.5 rounded-lg text-sm font-medium hover:bg-slate-50 transition">
                Cancelar
              </button>
              <button type="submit" id="submitReservationBtn"
                class="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-2.5 rounded-lg text-sm font-medium transition">
                Guardar
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  `;
}
