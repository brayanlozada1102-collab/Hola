import Sidebar from "@/components/Sidebar";
import { spacesController } from "@/controllers/spaces.controller";

export default function spacesView() {
  setTimeout(() => spacesController());

  return `
    <div class="flex h-screen overflow-hidden">
      ${Sidebar("/spaces")}

      <main class="flex-1 overflow-y-auto bg-slate-100">
        <div class="p-6 max-w-6xl mx-auto">

          <div class="flex items-center justify-between mb-6">
            <div>
              <h1 class="text-2xl font-bold text-slate-800">Espacios de Trabajo</h1>
              <p class="text-slate-500 text-sm mt-1">Gestión de espacios disponibles</p>
            </div>
            <button id="newSpaceBtn"
              class="flex items-center gap-2 bg-purple-600 hover:bg-purple-700 text-white px-4 py-2.5 rounded-lg text-sm font-medium transition">
              <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/>
              </svg>
              Nuevo espacio
            </button>
          </div>

          <div id="spacesContainer" class="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
            <div class="col-span-full text-center py-12">
              <p class="text-slate-400">Cargando espacios...</p>
            </div>
          </div>

        </div>
      </main>
    </div>

    <!-- Space Modal -->
    <div id="spaceModal" class="hidden fixed inset-0 bg-black/50 z-40 flex items-center justify-center p-4">
      <div class="bg-white rounded-2xl shadow-xl w-full max-w-md">
        <div class="p-6">
          <div class="flex items-center justify-between mb-5">
            <h2 class="text-xl font-bold text-slate-800" id="spaceModalTitle">Nuevo Espacio</h2>
            <button id="closeSpaceModal" class="text-slate-400 hover:text-slate-600 transition">
              <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
              </svg>
            </button>
          </div>

          <form id="spaceForm" novalidate class="space-y-4">
            <input type="hidden" id="spaceId">

            <div>
              <label class="block text-sm font-medium text-slate-700 mb-1">Nombre *</label>
              <input type="text" id="spaceName" placeholder="Ej: Sala de Reuniones A"
                class="border border-slate-300 w-full p-2.5 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 text-sm">
              <p class="text-red-500 text-xs mt-1 hidden" id="spaceNameError"></p>
            </div>

            <div>
              <label class="block text-sm font-medium text-slate-700 mb-1">Tipo *</label>
              <select id="spaceType"
                class="border border-slate-300 w-full p-2.5 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 text-sm">
                <option value="">Selecciona un tipo...</option>
                <option value="Sala de reuniones">Sala de reuniones</option>
                <option value="Oficina privada">Oficina privada</option>
                <option value="Espacio de coworking">Espacio de coworking</option>
                <option value="Auditorio">Auditorio</option>
              </select>
              <p class="text-red-500 text-xs mt-1 hidden" id="spaceTypeError"></p>
            </div>

            <div class="grid grid-cols-2 gap-3">
              <div>
                <label class="block text-sm font-medium text-slate-700 mb-1">Capacidad *</label>
                <input type="number" id="spaceCapacity" min="1" placeholder="Ej: 10"
                  class="border border-slate-300 w-full p-2.5 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 text-sm">
                <p class="text-red-500 text-xs mt-1 hidden" id="spaceCapacityError"></p>
              </div>
              <div>
                <label class="block text-sm font-medium text-slate-700 mb-1">Estado</label>
                <select id="spaceStatus"
                  class="border border-slate-300 w-full p-2.5 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 text-sm">
                  <option value="available">Disponible</option>
                  <option value="unavailable">No disponible</option>
                </select>
              </div>
            </div>

            <div>
              <label class="block text-sm font-medium text-slate-700 mb-1">Ubicación *</label>
              <input type="text" id="spaceLocation" placeholder="Ej: Piso 2"
                class="border border-slate-300 w-full p-2.5 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 text-sm">
              <p class="text-red-500 text-xs mt-1 hidden" id="spaceLocationError"></p>
            </div>

            <div id="spaceFormError" class="hidden bg-red-50 border border-red-200 text-red-700 text-sm rounded-lg p-3"></div>

            <div class="flex gap-3 pt-2">
              <button type="button" id="cancelSpaceBtn"
                class="flex-1 border border-slate-300 text-slate-700 py-2.5 rounded-lg text-sm font-medium hover:bg-slate-50 transition">
                Cancelar
              </button>
              <button type="submit" id="submitSpaceBtn"
                class="flex-1 bg-purple-600 hover:bg-purple-700 text-white py-2.5 rounded-lg text-sm font-medium transition">
                Guardar
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  `;
}
